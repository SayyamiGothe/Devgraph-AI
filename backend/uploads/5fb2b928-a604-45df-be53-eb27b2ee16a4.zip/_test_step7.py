"""Functional test of the /repositories endpoints through the ASGI stack."""

import zipfile
from pathlib import Path

# Neo4j is down: stub run_query before anything imports it.
import app.graph.neo4j_client as neo4j_client

CYPHER = []


def fake_run_query(query, parameters=None):
    CYPHER.append((" ".join(query.split()), parameters or {}))
    return []


neo4j_client.run_query = fake_run_query
import app.repositories.code_graph_repository as cgr  # noqa: E402

cgr.run_query = fake_run_query

from fastapi.testclient import TestClient  # noqa: E402

from app.core.security import create_access_token  # noqa: E402
from app.database.session import SessionLocal  # noqa: E402
from app.main import app  # noqa: E402
from app.models.project import Project  # noqa: E402
from app.models.user import User  # noqa: E402

BACKEND = Path(".")
ZIP = Path("_step7.zip")
EXCLUDE = {".venv", "__pycache__", ".git", "uploads", "node_modules"}


def build_zip():
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for p in BACKEND.rglob("*.py"):
            rel = p.relative_to(BACKEND)
            if any(x in EXCLUDE for x in rel.parts):
                continue
            z.write(p, str(rel))
        z.write("pyproject.toml", "pyproject.toml")


results = []


def check(label, condition, detail=""):
    results.append((label, condition, detail))
    print(f"  {'PASS' if condition else 'FAIL'}  {label}   {detail}")


def main():
    build_zip()

    db = SessionLocal()
    project = db.query(Project).first()
    user = (
        db.query(User)
        .filter(User.organisation_id == project.workspaces.organisation_id)
        .first()
    )
    other = (
        db.query(User)
        .filter(User.organisation_id != project.workspaces.organisation_id)
        .first()
    )
    db.close()

    token = create_access_token({"sub": str(user.id)})
    auth = {"Authorization": f"Bearer {token}"}

    client = TestClient(app)

    print("\n=== auth ===")
    r = client.get("/repositories", params={"project_id": project.id})
    check("unauthenticated -> 401", r.status_code == 401, str(r.status_code))

    print("\n=== validation ===")
    r = client.post(
        "/repositories/upload",
        headers=auth,
        data={"name": "x", "project_id": project.id},
        files={"file": ("notes.pdf", b"%PDF-1.4", "application/pdf")},
    )
    check("non-zip -> 400", r.status_code == 400, r.json().get("detail", ""))

    r = client.post(
        "/repositories/upload",
        headers=auth,
        data={"name": "x", "project_id": 999999},
        files={"file": ("r.zip", ZIP.read_bytes(), "application/zip")},
    )
    check("bad project -> 404", r.status_code == 404, r.json().get("detail", ""))

    print("\n=== upload ===")
    r = client.post(
        "/repositories/upload",
        headers=auth,
        data={"name": "step7-repo", "project_id": project.id},
        files={"file": ("r.zip", ZIP.read_bytes(), "application/zip")},
    )
    check("upload -> 201", r.status_code == 201, str(r.status_code))
    if r.status_code != 201:
        print(r.text[:500])
        return

    body = r.json()
    repo_id = body["id"]
    print(f"    {body}")
    check("status ready", body["status"] == "ready")
    check("nodes > 300", body["node_count"] > 300, str(body["node_count"]))
    check("edges > 500", body["edge_count"] > 500, str(body["edge_count"]))
    check("skipped == 0", body["skipped_count"] == 0)

    print("\n=== reads ===")
    r = client.get("/repositories", params={"project_id": project.id}, headers=auth)
    check("list -> 200", r.status_code == 200 and len(r.json()) >= 1)

    r = client.get(f"/repositories/{repo_id}", headers=auth)
    check("get -> 200", r.status_code == 200 and r.json()["id"] == repo_id)

    r = client.get(
        f"/repositories/{repo_id}/graph",
        params={"fqn": "app.services.document_service.DocumentService.create_document"},
        headers=auth,
    )
    check(
        "graph with Neo4j stubbed -> 404 (stub returns no rows)",
        r.status_code == 404,
        str(r.status_code),
    )

    print("\n=== authorization ===")
    if other:
        other_token = create_access_token({"sub": str(other.id)})
        r = client.get(
            f"/repositories/{repo_id}",
            headers={"Authorization": f"Bearer {other_token}"},
        )
        check("cross-org get -> 403", r.status_code == 403, str(r.status_code))
        r = client.get(
            f"/repositories/{repo_id}/graph",
            params={"fqn": "x"},
            headers={"Authorization": f"Bearer {other_token}"},
        )
        check("cross-org graph -> 403", r.status_code == 403, str(r.status_code))
    else:
        print("  SKIP  no second-org user in the database")

    print("\n=== idempotent re-upload ===")
    r = client.post(
        "/repositories/upload",
        headers=auth,
        data={"name": "step7-repo", "project_id": project.id},
        files={"file": ("r.zip", ZIP.read_bytes(), "application/zip")},
    )
    check("re-upload -> 201", r.status_code == 201)
    second = r.json()
    check(
        "counts unchanged, not doubled",
        second["node_count"] == body["node_count"],
        f"{body['node_count']} -> {second['node_count']}",
    )
    r = client.get("/repositories", params={"project_id": project.id}, headers=auth)
    named = [x for x in r.json() if x["name"] == "step7-repo"]
    check("only one row for the name", len(named) == 1, str(len(named)))

    print("\n=== cypher issued ===")
    labels = sorted({q.split("SET n:")[1] for q, _ in CYPHER if "SET n:" in q})
    etypes = sorted(
        {q.split("MERGE (a)-[:")[1].split("]")[0] for q, _ in CYPHER if "MERGE (a)-[:" in q}
    )
    deletes = [q for q, _ in CYPHER if "DETACH DELETE" in q]
    print(f"    labels={labels} edges={etypes} detach_deletes={len(deletes)}")
    check("delete-before-reingest fired", len(deletes) >= 1)

    print("\n=== cleanup ===")
    r = client.delete(f"/repositories/{second['id']}", headers=auth)
    check("delete -> 200", r.status_code == 200)
    r = client.get(f"/repositories/{second['id']}", headers=auth)
    check("gone -> 404", r.status_code == 404)

    ZIP.unlink(missing_ok=True)

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n{passed}/{len(results)} passed")


if __name__ == "__main__":
    main()
